package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.Review;
import com.ltimindtree.exception.ReviewNotFoundException;
import com.ltimindtree.service.impl.ReviewServiceImpl;

@RestController
@RequestMapping("/reviews")
public class ReviewController {
	
	@Autowired
	private ReviewServiceImpl reviewImpl;
	
	private Map<String, Object> response;
	
	
	//localhost:8080/reviews/provideReview
	@PostMapping("/provideReview")
	public ResponseEntity<Map<String, Object>> provideReviews(@RequestBody Review review){
		response=new HashMap<String, Object>();
		response.put("message", "Review Provided successfully");
		response.put("status",HttpStatus.OK);
		response.put("body", reviewImpl.createReview(review));
		response.put("error",false);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}
	
	//localhost:8080/reviews/viewReview
	@GetMapping("/viewReview/{id}")
	public ResponseEntity<Map<String, Object>> viewReviews(@PathVariable (value = "id") int id) throws ReviewNotFoundException{
		response=new HashMap<String, Object>();
		response.put("message", "Review Provided successfully");
		response.put("status",HttpStatus.OK);
		response.put("body", reviewImpl.getReviewById(id));
		response.put("error",false);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}
	
	//localhost:8080/reviews/updateReview/
	@PutMapping("/updateReview/{id}")
	public ResponseEntity<Map<String, Object>> updateReview(@RequestBody Review review, @PathVariable (value = "id") int id) throws ReviewNotFoundException{
		response=new HashMap<String, Object>();
		response.put("message", "Review Provided successfully");
		response.put("status",HttpStatus.OK);
		response.put("body", reviewImpl.updateReview(review, id));
		response.put("error",false);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}

}
